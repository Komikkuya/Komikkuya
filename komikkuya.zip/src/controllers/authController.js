const fetch = require('node-fetch');
const FormData = require('form-data');

const AUTH_API_BASE = 'https://auth.komikkuya.my.id';
const HCAPTCHA_SECRET = process.env.HCAPTCHA_SECRET || 'ES_ed8da6c97c95492a8bf0205c1f3e155a'; // Should be in .env

// Helper for hCaptcha verification
const verifyCaptcha = async (token) => {
    try {
        if (!token) return false;

        const response = await fetch('https://hcaptcha.com/siteverify', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `secret=${HCAPTCHA_SECRET}&response=${token}`
        });

        const data = await response.json();
        return data.success;
    } catch (e) {
        console.error('hCaptcha Error:', e);
        return false;
    }
};

const authController = {
    // Show login page
    showLogin: (req, res) => {
        // If already logged in, redirect to dashboard
        if (res.locals.user) {
            return res.redirect('/auth/dashboard');
        }

        res.render('auth/login', {
            layout: 'layouts/main',
            title: 'Login - Komikkuya',
            metaDescription: 'Login ke akun Komikkuya untuk akses fitur premium',
            error: req.query.error || null,
            success: req.query.success || null
        });
    },

    // Show register page
    showRegister: (req, res) => {
        // If already logged in, redirect to dashboard
        if (res.locals.user) {
            return res.redirect('/auth/dashboard');
        }

        res.render('auth/register', {
            layout: 'layouts/main',
            title: 'Daftar - Komikkuya',
            metaDescription: 'Daftar akun Komikkuya gratis untuk akses fitur premium',
            error: req.query.error || null
        });
    },

    // Handle login
    login: async (req, res) => {
        try {
            const { email, password, 'h-captcha-response': captchaToken } = req.body;

            if (!email || !password) {
                return res.redirect('/auth/login?error=' + encodeURIComponent('Email dan password wajib diisi'));
            }

            // Verify Captcha
            const isCaptchaValid = await verifyCaptcha(captchaToken);
            if (!isCaptchaValid) {
                return res.redirect('/auth/login?error=' + encodeURIComponent('Silahkan selesaikan captcha terlebih dahulu'));
            }

            const response = await fetch(`${AUTH_API_BASE}/auth/login`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ email, password })
            });

            const data = await response.json();

            if (!response.ok || !data.success) {
                return res.redirect('/auth/login?error=' + encodeURIComponent(data.message || 'Login gagal'));
            }

            // Set JWT token in cookie (httpOnly for security)
            res.cookie('komikkuya_token', data.data.token, {
                httpOnly: true,
                secure: process.env.NODE_ENV === 'production',
                maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
                sameSite: 'lax'
            });

            // Redirect to dashboard
            res.redirect('/auth/dashboard');
        } catch (error) {
            console.error('Login error:', error);
            res.redirect('/auth/login?error=' + encodeURIComponent('Terjadi kesalahan server'));
        }
    },

    // Handle register
    register: async (req, res) => {
        try {
            const { email, password, username, 'h-captcha-response': captchaToken } = req.body;

            if (!email || !password || !username) {
                return res.redirect('/auth/register?error=' + encodeURIComponent('Semua field wajib diisi'));
            }

            // Verify Captcha
            const isCaptchaValid = await verifyCaptcha(captchaToken);
            if (!isCaptchaValid) {
                return res.redirect('/auth/register?error=' + encodeURIComponent('Silahkan selesaikan captcha terlebih dahulu'));
            }

            const response = await fetch(`${AUTH_API_BASE}/auth/register`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ email, password, username })
            });

            const data = await response.json();

            if (!response.ok || !data.success) {
                return res.redirect('/auth/register?error=' + encodeURIComponent(data.message || 'Registrasi gagal'));
            }

            // Set JWT token in cookie
            res.cookie('komikkuya_token', data.data.token, {
                httpOnly: true,
                secure: process.env.NODE_ENV === 'production',
                maxAge: 7 * 24 * 60 * 60 * 1000,
                sameSite: 'lax'
            });

            // Redirect to dashboard
            res.redirect('/auth/dashboard');
        } catch (error) {
            console.error('Register error:', error);
            res.redirect('/auth/register?error=' + encodeURIComponent('Terjadi kesalahan server'));
        }
    },

    // Discord Auth Redirect
    discordRedirect: (req, res) => {
        // Backend handles Discord OAuth redirect
        res.redirect(`${AUTH_API_BASE}/auth/discord`);
    },

    // Discord Link (for logged in users to connect Discord)
    discordLink: (req, res) => {
        const token = req.cookies.komikkuya_token;
        if (!token) {
            return res.redirect('/auth/login?error=' + encodeURIComponent('Kamu harus login terlebih dahulu'));
        }
        // Redirect to backend with token as query param
        res.redirect(`${AUTH_API_BASE}/auth/discord/link?token=${encodeURIComponent(token)}`);
    },

    // Auth Callback - receives token from backend and sets cookie
    authCallback: (req, res) => {
        const { token, error } = req.query;

        if (error) {
            // Handle specific Discord auth errors
            if (error === 'discord_auth_failed' || error.includes('not registered')) {
                return res.redirect('/auth/register?error=' + encodeURIComponent('Akun Discord belum terdaftar. Silahkan daftar terlebih dahulu atau hubungkan Discord ke akun yang sudah ada.'));
            }
            return res.redirect('/auth/login?error=' + encodeURIComponent(error));
        }

        if (!token) {
            return res.redirect('/auth/login?error=' + encodeURIComponent('Token tidak ditemukan'));
        }

        // Set JWT token in cookie
        res.cookie('komikkuya_token', token, {
            httpOnly: true,
            secure: process.env.NODE_ENV === 'production',
            maxAge: 7 * 24 * 60 * 60 * 1000,
            sameSite: 'lax'
        });

        res.redirect('/auth/dashboard');
    },

    // Discord Auth Callback
    discordCallback: async (req, res) => {
        try {
            const { code } = req.query;

            if (!code) {
                return res.redirect('/auth/login?error=' + encodeURIComponent('Discord code not found'));
            }

            const response = await fetch(`${AUTH_API_BASE}/auth/discord`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ code, redirect_uri: `${req.protocol}://${req.get('host')}/auth/discord/callback` })
            });

            const data = await response.json();

            if (!response.ok || !data.success) {
                return res.redirect('/auth/login?error=' + encodeURIComponent(data.message || 'Discord login failed'));
            }

            // Set JWT token in cookie
            res.cookie('komikkuya_token', data.data.token, {
                httpOnly: true,
                secure: process.env.NODE_ENV === 'production',
                maxAge: 7 * 24 * 60 * 60 * 1000,
                sameSite: 'lax'
            });

            res.redirect('/auth/dashboard');
        } catch (error) {
            console.error('Discord callback error:', error);
            res.redirect('/auth/login?error=' + encodeURIComponent('Terjadi kesalahan saat login Discord'));
        }
    },

    // Handle logout
    logout: (req, res) => {
        res.clearCookie('komikkuya_token');
        res.redirect('/auth/login?success=' + encodeURIComponent('Berhasil logout'));
    },

    // Show dashboard (protected)
    dashboard: async (req, res) => {
        try {
            if (!res.locals.user) {
                return res.redirect('/auth/login');
            }

            res.render('auth/dashboard', {
                layout: 'layouts/main',
                title: 'Dashboard - Komikkuya',
                metaDescription: 'Dashboard akun Komikkuya',
                user: res.locals.user,
                error: req.query.error || null,
                success: req.query.success || null
            });
        } catch (error) {
            console.error('Dashboard error:', error);
            res.redirect('/auth/login?error=' + encodeURIComponent('Terjadi kesalahan'));
        }
    },

    // Update profile
    updateProfile: async (req, res) => {
        try {
            const token = req.cookies.komikkuya_token;
            if (!token) {
                return res.redirect('/auth/login');
            }

            const { username, email } = req.body;

            const response = await fetch(`${AUTH_API_BASE}/auth/profile`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({ username, email })
            });

            const data = await response.json();

            if (!response.ok || !data.success) {
                return res.redirect('/auth/dashboard?error=' + encodeURIComponent(data.message || 'Gagal update profil'));
            }

            res.redirect('/auth/dashboard?success=' + encodeURIComponent('Profil berhasil diupdate'));
        } catch (error) {
            console.error('Update profile error:', error);
            res.redirect('/auth/dashboard?error=' + encodeURIComponent('Terjadi kesalahan'));
        }
    },

    // Upload profile picture
    uploadProfilePicture: async (req, res) => {
        try {
            const token = req.cookies.komikkuya_token;
            if (!token) {
                return res.redirect('/auth/login');
            }

            if (!req.file) {
                return res.redirect('/auth/dashboard?error=' + encodeURIComponent('File tidak ditemukan'));
            }

            const formData = new FormData();
            formData.append('file', req.file.buffer, {
                filename: req.file.originalname,
                contentType: req.file.mimetype
            });

            const response = await fetch(`${AUTH_API_BASE}/auth/profile-picture`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`
                },
                body: formData
            });

            const data = await response.json();

            if (!response.ok || !data.success) {
                return res.redirect('/auth/dashboard?error=' + encodeURIComponent(data.message || 'Gagal upload foto'));
            }

            res.redirect('/auth/dashboard?success=' + encodeURIComponent('Foto profil berhasil diupdate'));
        } catch (error) {
            console.error('Upload profile picture error:', error);
            res.redirect('/auth/dashboard?error=' + encodeURIComponent('Terjadi kesalahan'));
        }
    },

    // Delete profile picture
    deleteProfilePicture: async (req, res) => {
        try {
            const token = req.cookies.komikkuya_token;
            if (!token) {
                return res.redirect('/auth/login');
            }

            const response = await fetch(`${AUTH_API_BASE}/auth/profile-picture`, {
                method: 'DELETE',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });

            const data = await response.json();

            if (!response.ok || !data.success) {
                return res.redirect('/auth/dashboard?error=' + encodeURIComponent(data.message || 'Gagal hapus foto'));
            }

            res.redirect('/auth/dashboard?success=' + encodeURIComponent('Foto profil berhasil dihapus'));
        } catch (error) {
            console.error('Delete profile picture error:', error);
            res.redirect('/auth/dashboard?error=' + encodeURIComponent('Terjadi kesalahan'));
        }
    },

    // Get user settings
    getSettings: async (req, res) => {
        try {
            const token = req.cookies.komikkuya_token;
            if (!token) {
                return res.json({ success: false, message: 'Not authenticated' });
            }

            const response = await fetch(`${AUTH_API_BASE}/settings`, {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });

            const data = await response.json();
            return res.json(data);
        } catch (error) {
            console.error('Get settings error:', error);
            return res.json({ success: false, message: 'Failed to get settings' });
        }
    },

    // Update user settings (toggle)
    updateSettings: async (req, res) => {
        try {
            const token = req.cookies.komikkuya_token;
            if (!token) {
                return res.json({ success: false, message: 'Not authenticated' });
            }

            const { show_favorites, show_reading_history } = req.body;

            const response = await fetch(`${AUTH_API_BASE}/settings`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({ show_favorites, show_reading_history })
            });

            const data = await response.json();
            return res.json(data);
        } catch (error) {
            console.error('Update settings error:', error);
            return res.json({ success: false, message: 'Failed to update settings' });
        }
    },

    // Get reading history
    getReadingHistory: async (req, res) => {
        try {
            const token = req.cookies.komikkuya_token;
            if (!token) {
                return res.json({ success: false, message: 'Not authenticated' });
            }

            const response = await fetch(`${AUTH_API_BASE}/reading-history`, {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });

            const data = await response.json();
            return res.json(data);
        } catch (error) {
            console.error('Get reading history error:', error);
            return res.json({ success: false, message: 'Failed to get reading history' });
        }
    },

    // Add/update reading history (upsert)
    addReadingHistory: async (req, res) => {
        try {
            const token = req.cookies.komikkuya_token;
            if (!token) {
                return res.json({ success: false, message: 'Not authenticated' });
            }

            const { title, chapterTitle, url, image, type, time } = req.body;

            const response = await fetch(`${AUTH_API_BASE}/reading-history`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({ title, chapterTitle, url, image, type, time })
            });

            const data = await response.json();
            return res.json(data);
        } catch (error) {
            console.error('Add reading history error:', error);
            return res.json({ success: false, message: 'Failed to add reading history' });
        }
    },

    // Delete single reading history entry
    deleteReadingHistory: async (req, res) => {
        try {
            const token = req.cookies.komikkuya_token;
            if (!token) {
                return res.json({ success: false, message: 'Not authenticated' });
            }

            const { title } = req.body;

            const response = await fetch(`${AUTH_API_BASE}/reading-history`, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({ title })
            });

            const data = await response.json();
            return res.json(data);
        } catch (error) {
            console.error('Delete reading history error:', error);
            return res.json({ success: false, message: 'Failed to delete reading history' });
        }
    },

    // Delete all reading history
    deleteAllReadingHistory: async (req, res) => {
        try {
            const token = req.cookies.komikkuya_token;
            if (!token) {
                return res.json({ success: false, message: 'Not authenticated' });
            }

            const response = await fetch(`${AUTH_API_BASE}/reading-history/all`, {
                method: 'DELETE',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });

            const data = await response.json();
            return res.json(data);
        } catch (error) {
            console.error('Delete all reading history error:', error);
            return res.json({ success: false, message: 'Failed to delete all reading history' });
        }
    },

    // Get all favorites
    getFavorites: async (req, res) => {
        try {
            const token = req.cookies.komikkuya_token;
            if (!token) {
                return res.json({ success: false, message: 'Not authenticated' });
            }

            const response = await fetch(`${AUTH_API_BASE}/favorites`, {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });

            const data = await response.json();
            return res.json(data);
        } catch (error) {
            console.error('Get favorites error:', error);
            return res.json({ success: false, message: 'Failed to get favorites' });
        }
    },

    // Add favorite
    addFavorite: async (req, res) => {
        try {
            const token = req.cookies.komikkuya_token;
            if (!token) {
                return res.json({ success: false, message: 'Not authenticated' });
            }

            const { id, slug, title, cover, type, source } = req.body;

            const response = await fetch(`${AUTH_API_BASE}/favorites`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({ id, slug, title, cover, type, source })
            });

            const data = await response.json();
            return res.json(data);
        } catch (error) {
            console.error('Add favorite error:', error);
            return res.json({ success: false, message: 'Failed to add favorite' });
        }
    },

    // Remove favorite
    removeFavorite: async (req, res) => {
        try {
            const token = req.cookies.komikkuya_token;
            if (!token) {
                return res.json({ success: false, message: 'Not authenticated' });
            }

            const { id } = req.params;

            const response = await fetch(`${AUTH_API_BASE}/favorites/${id}`, {
                method: 'DELETE',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });

            const data = await response.json();
            return res.json(data);
        } catch (error) {
            console.error('Remove favorite error:', error);
            return res.json({ success: false, message: 'Failed to remove favorite' });
        }
    },

    // Check if favorited
    checkFavorite: async (req, res) => {
        try {
            const token = req.cookies.komikkuya_token;
            if (!token) {
                return res.json({ success: false, favorited: false });
            }

            const { id } = req.params;

            const response = await fetch(`${AUTH_API_BASE}/favorites/check/${id}`, {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });

            const data = await response.json();
            return res.json(data);
        } catch (error) {
            console.error('Check favorite error:', error);
            return res.json({ success: false, favorited: false });
        }
    },

    // ==================== PUBLIC ENDPOINTS (No Auth Required) ====================

    // Get public profile
    getPublicProfile: async (req, res) => {
        try {
            const { userId } = req.params;

            const response = await fetch(`${AUTH_API_BASE}/public/user/${userId}`, {
                method: 'GET'
            });

            const data = await response.json();
            return res.json(data);
        } catch (error) {
            console.error('Get public profile error:', error);
            return res.json({ success: false, message: 'Failed to get public profile' });
        }
    },

    // Get public favorites
    getPublicFavorites: async (req, res) => {
        try {
            const { userId } = req.params;

            const response = await fetch(`${AUTH_API_BASE}/public/favorites/${userId}`, {
                method: 'GET'
            });

            const data = await response.json();
            return res.json(data);
        } catch (error) {
            console.error('Get public favorites error:', error);
            return res.json({ success: false, message: 'Failed to get public favorites' });
        }
    },

    // Get public reading history
    getPublicReadingHistory: async (req, res) => {
        try {
            const { userId } = req.params;
            const limit = req.query.limit || 20;

            const response = await fetch(`${AUTH_API_BASE}/public/reading-history/${userId}?limit=${limit}`, {
                method: 'GET'
            });

            const data = await response.json();
            return res.json(data);
        } catch (error) {
            console.error('Get public reading history error:', error);
            return res.json({ success: false, message: 'Failed to get public reading history' });
        }
    }
};

module.exports = authController;




